# MPLP - Multi-Agent Project Lifecycle Protocol

[![npm version](https://badge.fury.io/js/mplp.svg)](https://badge.fury.io/js/mplp)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/%3C%2F%3E-TypeScript-%230074c1.svg)](http://www.typescriptlang.org/)

一个用于多智能体协作和工作流编排的综合框架。

## 🚀 特性

- **多智能体协作**: 支持复杂的多智能体工作流编排
- **高性能**: 内置缓存和批处理优化，性能提升57%+
- **类型安全**: 完整的TypeScript支持
- **可扩展**: 模块化设计，易于扩展
- **生产就绪**: 完整的错误处理、重试机制和监控

## 📦 安装

```bash
npm install mplp
```

## 🎯 快速开始

### 基础使用

```typescript
import { CoreOrchestrator } from 'mplp';

// 创建调度器
const orchestrator = new CoreOrchestrator({
  default_workflow: {
    stages: ['context', 'plan', 'confirm', 'trace'],
    parallel_execution: false,
    timeout_ms: 30000
  },
  module_timeout_ms: 10000,
  max_concurrent_executions: 50
});

// 注册模块
orchestrator.registerModule(yourModule);

// 执行工作流
const result = await orchestrator.executeWorkflow('context-id');
```


### 性能优化使用

```typescript
import { PerformanceEnhancedOrchestrator } from 'mplp';

// 创建性能增强调度器
const orchestrator = new PerformanceEnhancedOrchestrator(config);

// 预热缓存
await orchestrator.warmupCache(['common-context-1', 'common-context-2']);

// 执行工作流 (自动缓存优化)
const result = await orchestrator.executeWorkflow('context-id');

// 查看性能统计
const stats = orchestrator.getPerformanceStats();
console.log(`缓存命中率: ${(stats.cacheHitRate * 100).toFixed(1)}%`);
```

## 📊 性能对比

| 版本 | 响应时间 | 吞吐量 | 缓存优化 |
|------|----------|--------|----------|
| CoreOrchestrator | 347ms | 37 ops/sec | - |
| PerformanceEnhancedOrchestrator | 148ms (缓存命中) | 37+ ops/sec | 57%提升 |


## 📚 文档

- [API 参考](./docs/api-reference.md)
- [性能优化指南](./docs/performance-guide.md)
- [示例代码](./examples/)

## 🧪 测试

```bash
# 运行所有测试
npm test

# 运行性能测试
npm run test:performance

# 运行单元测试
npm run test:unit
```

## 🤝 贡献

欢迎贡献代码！请查看 [贡献指南](./CONTRIBUTING.md)。

## 📄 许可证

MIT License - 查看 [LICENSE](./LICENSE) 文件了解详情。

## 🔗 相关链接

- [GitHub 仓库](https://github.com/your-org/mplp)
- [问题反馈](https://github.com/your-org/mplp/issues)
- [更新日志](./CHANGELOG.md)
