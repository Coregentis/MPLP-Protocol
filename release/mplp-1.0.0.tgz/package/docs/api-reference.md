# MPLP API 参考

## 核心类

### CoreOrchestrator

基础的工作流调度器，提供完整的多智能体协作功能。

```typescript
import { CoreOrchestrator } from 'mplp';

const orchestrator = new CoreOrchestrator(config);
await orchestrator.executeWorkflow(contextId);
```


### PerformanceEnhancedOrchestrator

性能增强版调度器，在基础功能上添加了缓存、批处理等优化。

```typescript
import { PerformanceEnhancedOrchestrator } from 'mplp';

const orchestrator = new PerformanceEnhancedOrchestrator(config);
await orchestrator.executeWorkflow(contextId);

// 查看性能统计
const stats = orchestrator.getPerformanceStats();
```

#### 性能优化功能

- **智能缓存**: 自动缓存工作流结果，缓存命中时性能提升57%+
- **批处理**: 自动批量处理I/O操作，减少系统开销
- **性能监控**: 实时监控性能指标，支持告警
- **资源管理**: 智能的连接池和资源管理

### 性能工具包

#### IntelligentCacheManager
智能缓存管理器，支持LFU+LRU混合淘汰策略。

#### BatchProcessor
批处理器，自动批量处理操作以提升性能。

#### BusinessPerformanceMonitor
业务性能监控器，提供实时性能指标和告警。


## 配置选项

### OrchestratorConfiguration

```typescript
interface OrchestratorConfiguration {
  default_workflow: WorkflowConfiguration;
  module_timeout_ms: number;
  max_concurrent_executions: number;
  enable_performance_monitoring: boolean;
  enable_event_logging: boolean;
}
```

## 性能基准

基于真实业务逻辑的性能测试结果：

| 指标 | CoreOrchestrator | PerformanceEnhancedOrchestrator |
|------|------------------|--------------------------------|
| 平均响应时间 | 347ms | 347ms (首次) / 148ms (缓存) |
| 吞吐量 | 37 ops/sec | 37+ ops/sec |
| 缓存优化 | - | 57%性能提升 |
| 内存效率 | 良好 | 优秀 |
